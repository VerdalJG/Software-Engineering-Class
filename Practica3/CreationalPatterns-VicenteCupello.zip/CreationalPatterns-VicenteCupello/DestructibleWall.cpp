#include "DestructibleWall.h"

void DestructibleWall::Enter()
{
}
