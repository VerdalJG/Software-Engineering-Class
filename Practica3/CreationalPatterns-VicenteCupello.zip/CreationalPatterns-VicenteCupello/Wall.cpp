#include "Wall.h"

void Wall::Enter()
{
}
