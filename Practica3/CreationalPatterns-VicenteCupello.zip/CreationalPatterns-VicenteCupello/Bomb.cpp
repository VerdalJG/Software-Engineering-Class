#include "Bomb.h"

Bomb::Bomb(unsigned int RoomID) :
	Room(RoomID)
{
}

void Bomb::Enter()
{
}
