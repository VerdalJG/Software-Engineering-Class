#pragma once

void GoToX(int x);

void HideCursor();

void Clear();
