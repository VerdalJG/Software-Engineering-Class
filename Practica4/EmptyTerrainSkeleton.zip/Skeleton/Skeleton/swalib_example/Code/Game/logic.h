#ifndef _LOGIC_H_
#define _LOGIC_H_

// Logic slot.
void LogicSlot();

#endif // !_LOGIC_H_
