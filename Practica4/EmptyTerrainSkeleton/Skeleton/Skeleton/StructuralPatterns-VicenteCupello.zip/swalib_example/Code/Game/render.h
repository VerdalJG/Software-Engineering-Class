#ifndef _RENDER_H_
#define _RENDER_H_

// Render initialization.
void InitRender();
// Render slot.
void RenderSlot();
// Render shutdown.
void ShutDownRender();

#endif // !_RENDER_H_

