#include "logic.h"
#include "../../../common/stdafx.h"
#include "../../../common/core.h"
#include "../../../common/sys.h"
#include "../../../common/vector2d.h"
#include "global.h"


void LogicSlot()
{
}
